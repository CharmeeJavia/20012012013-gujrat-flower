<nav class="navbar navbar-inverse navabar-fixed-top">
               <div class="container">
                   <div class="navbar-header">
                       <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                       </button>
                       <a href="index.php" class="navbar-brand">Gujarat Flowers</a>
                   </div>
                   
                   <div class="collapse navbar-collapse" id="myNavbar">
                       <ul class="nav navbar-nav navbar-right">
                           <?php
                           if(isset($_SESSION['email'])){
                           ?>
                           <li>
                            <?php
                            $cart_count = 0;
                            $user_products="select GROUP_CONCAT(item_id) as cart_item_id from users_items ut where ut.user_id='".$_SESSION['id']."' AND status='Added to cart'";
                              $user_products_res=mysqli_query($con,$user_products) or die(mysqli_error($con));
                              $row=mysqli_fetch_array($user_products_res);

                                    if(!empty($_SESSION["cart_item_total"])) {
                                        $cart_count = count(array_keys($_SESSION["cart_item_total"]));
                                       
                                    } else if (!empty($row['cart_item_id'])) {
                                       $_SESSION["cart_item_total"] = explode(',', $row['cart_item_id']);
                                       $cart_count = $_SESSION["cart_item_total"];
                                    }
                                ?>
                                
                            <a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart <span class="cart_badge badge"><?= $cart_count; ?></span></a>
                            </li>
                           <li><a href="settings.php"><span class="glyphicon glyphicon-cog"></span> Settings</a></li>
                           <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                           <?php
                           }else{
                            ?>
                            <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                           <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                           
                           <?php
                           }
                           ?>
                           
                       </ul>
                   </div>
               </div>
</nav>