<?php
    include_once "../config/dbconnect.php";

    if(isset($_POST['upload']))
    {
       
        $catname = $_POST['c_name'];        
        $name = $_FILES['file']['name'];
        $temp = $_FILES['file']['tmp_name'];
    
        $target_dir="../../img/";
        $finalImage=$target_dir.$name;

        move_uploaded_file($temp,$finalImage);

         $insert = mysqli_query($conn,"INSERT INTO category
         (category_name,category_img) 
         VALUES ('$catname','$name')");
 
          if(!$insert)
         {
            $error = mysqli_error($conn);
            ?>
            <script>
                window.alert("Error in insert category.");
            </script>
            <meta http-equiv="refresh" content="1;url=../index.php" />
        
        <?php 
         } else { ?>

            <script>
                window.alert("Records added successfully.");
            </script>
            <meta http-equiv="refresh" content="1;url=../index.php" />

        <?php }
     
    }

        
?>