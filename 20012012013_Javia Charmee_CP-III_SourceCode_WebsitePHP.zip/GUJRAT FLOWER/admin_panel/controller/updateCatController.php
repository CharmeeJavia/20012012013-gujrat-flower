<?php
    include_once "../config/dbconnect.php";

    $cat_id=$_POST['cat_id'];
    $category_name= $_POST['category_name'];

    if( isset($_FILES['newImage']) ){
        
        $img = $_FILES['newImage']['name'];
        $tmp = $_FILES['newImage']['tmp_name'];
        $dir = '../../img/';
        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
        $valid_extensions = array('jpeg', 'jpg', 'png', 'gif','webp');
        $image =rand(1000,1000000).".".$ext;
        $final_image=$image;
        if (in_array($ext, $valid_extensions)) {
            move_uploaded_file($tmp, $dir.$image);
        }

        /* delete old image from folder */
        $sql="SELECT * from category where category_id ='$cat_id'";
        $res=mysqli_query($conn,$sql);
        $row=mysqli_fetch_array($res);
        $filePath = "../../img/".$row['category_img'];
        if (file_exists($filePath)) {
            unlink($filePath);
        }
    }else{
        $final_image=$_POST['existingImage'];
    }

    $updateItem = mysqli_query($conn,"UPDATE category SET 
        category_name='$category_name',        
        category_img='$final_image' 
        WHERE category_id=$cat_id");

    if($updateItem)
    {
        echo "true";
    }
    // else
    // {
    //     echo mysqli_error($conn);
    // }
?>