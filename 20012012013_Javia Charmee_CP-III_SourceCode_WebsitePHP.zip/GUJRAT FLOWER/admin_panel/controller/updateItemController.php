<?php
    include_once "../config/dbconnect.php";

    $product_id=$_POST['product_id'];
    $p_name= $_POST['p_name'];
    $p_price= $_POST['p_price'];
    $category= $_POST['category'];

    if( isset($_FILES['newImage']) ){
        
        $location="./uploads/";
        $img = $_FILES['newImage']['name'];
        $tmp = $_FILES['newImage']['tmp_name'];
        $dir = '../../img/';
        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
        $valid_extensions = array('jpeg', 'jpg', 'png', 'gif','webp');
        $image =rand(1000,1000000).".".$ext;
        $final_image=$image;
        if (in_array($ext, $valid_extensions)) {
            move_uploaded_file($tmp, $dir.$image);
        }

        /* delete old image from folder */
        $sql="SELECT * from items where id ='$product_id'";
        $res=mysqli_query($conn,$sql);
        $row=mysqli_fetch_array($res);
        $filePath = "../../img/".$row['image'];
        if (file_exists($filePath)) {
            unlink($filePath);
        }

    }else{
        $final_image=$_POST['existingImage'];
    }

    $updateItem = mysqli_query($conn,"UPDATE items SET 
        name='$p_name', 
        price=$p_price,
        category_id=$category,
        image='$final_image' 
        WHERE id=$product_id");

    if($updateItem)
    {
        echo "true";
    }
    // else
    // {
    //     echo mysqli_error($conn);
    // }
?>