<?php

    include_once "../config/dbconnect.php";
    
    $c_id=$_POST['record'];

    $sql="SELECT * from category where category_id ='$c_id'";
    $res=mysqli_query($conn,$sql);
    $row=mysqli_fetch_array($res);

    $query="DELETE FROM category where category_id='$c_id'";
    $data=mysqli_query($conn,$query);


    $filePath = "../../img/".$row['category_img'];
    if (file_exists($filePath)) {
        unlink($filePath);
    }

    if($data){
        echo"Category Item Deleted";
    }
    else{
        echo"Not able to delete";
    }
    
?>