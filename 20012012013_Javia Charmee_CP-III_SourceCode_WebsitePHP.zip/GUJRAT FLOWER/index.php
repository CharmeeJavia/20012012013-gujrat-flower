<?php
session_start();
include "connection.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/logo.png"/>
        <title>Gujarat Flowers</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
    <body>
        <div>
           <?php
            require 'header.php';
           ?>
           <div id="bannerImage">
               <div class="container">
                   <center>
                   <div id="bannerContent">
                       <h3>Gujarat Flowers Supplier We are Manufacturing and Supplying of Artificial Flowers of All india on Wholesale Rates. We are leading Artificial Flowers Manufacturer in Surat Gujarat. For more information please contact us on 9712962233</h3>
                      
                   </div>
                   </center>
               </div>
           </div>
           <div class="container">
               <div class="row">
                <?php
                    $query = "SELECT * FROM category";
                    $result = mysqli_query($con,$query);
                    while($row = mysqli_fetch_assoc($result)){
                        echo '
                        <div class="col-xs-4">
                        <div  class="thumbnail">
                            <a href="products.php?id='.$row['category_id'].'">
                                 <img src="img/'.$row['category_img'].'" alt="Camera">
                            </a>
                            <center>
                                 <div class="caption">
                                         <p id="autoResize">'.$row["category_name"].'</p>
                                         <p>Choose among the best available.</p>
                                 </div>
                            </center>
                        </div>
                    </div>
                    
                        ';
                    }
                ?>
               </div>
           </div>
            <br><br> <br><br><br><br>
           
        </div>
    </body>
</html>